const toggle = document.getElementById("toggle");
const apiKeyInput = document.getElementById("apiKey");

chrome.storage.local.get(["heyClaudeEnabled", "openaiApiKey"], (r) => {
  toggle.checked = !!r.heyClaudeEnabled;
  apiKeyInput.value = r.openaiApiKey || "";
});

toggle.addEventListener("change", async () => {
  const enabled = toggle.checked;
  chrome.storage.local.set({ heyClaudeEnabled: enabled });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url && tab.url.includes("claude.ai")) {
    chrome.tabs.sendMessage(tab.id, { type: "TOGGLE", enabled });
  }
});

apiKeyInput.addEventListener("change", () => {
  chrome.storage.local.set({ openaiApiKey: apiKeyInput.value.trim() });
});
