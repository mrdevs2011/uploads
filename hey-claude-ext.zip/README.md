# Hey Claude — Whisper Voice (EN/UZ, to'liq onlayn)

O'rnatish:
1. `chrome://extensions` ochib, "Developer mode"ni yoq.
2. "Load unpacked" bos, shu papkani (`hey-claude-ext`) tanla.
3. Extension icon'ini bosib, OpenAI API key'ni kirit (platform.openai.com/api-keys
   dan olasan) va "Faol" checkbox'ni yoq.
4. claude.ai'ni och — pastki o'ng burchakda kichik nuqta (badge) chiqadi,
   mikrofon ruxsatini ber.
5. "Hey Claude" de, keyin so'rovingni ayt (inglizcha yoki o'zbekcha) — jim
   qolganingda (~1.2s) avtomatik matn yoziladi va yuboriladi.

## Qanday ishlaydi
- Wake-word ("Hey Claude") — brauzerning ichki tez tanish tizimi orqali
  (Google'ning bulutli xizmati, internet talab qiladi).
- Wake-word eshitilgach — mikrofon yozadi, jim bo'lguningcha (yoki 20s dan
  keyin) to'xtaydi.
- Yozilgan ovoz **OpenAI Whisper API**ga (`whisper-1`) yuboriladi va matnga
  o'giriladi — to'liq onlayn, lokal model yo'q, hech narsa yuklab olinmaydi.
  Til avtomatik aniqlanadi (inglizcha/o'zbekcha).
- Natija claude.ai'ning yozish maydoniga qo'yiladi va yuborish tugmasi
  avtomatik bosiladi.

## Narx
Whisper API pullik: taxminan $0.006/daqiqa audio. API key'ni
platform.openai.com'da yaratasan, to'lov usulini ulashing kerak bo'ladi.

## Sozlash / moslashtirish
- `content.js` ichidagi `SILENCE_MS`, `SILENCE_RMS`, `MAX_RECORD_MS` —
  mikrofoningga qarab moslashtirish uchun.
- claude.ai sayti DOM'ini o'zgartirsa, `findInput()` / `findSendButton()`
  ichidagi selectorlarni devtools orqali tekshirib yangilash kerak bo'lishi
  mumkin — bu qism saytga bog'liq va vaqti-vaqti bilan buzilishi mumkin.

## Cheklovlar
- Faqat claude.ai domenida ishlaydi.
- Wake-word tanish inglizcha ("hey claude" va talaffuz variantlari) —
  bu qism o'zgarmaydi, lekin undan keyingi buyruq istalgan tilda bo'lishi
  mumkin.
- API key `chrome.storage.local`da (shu brauzer/profilda) saqlanadi.
