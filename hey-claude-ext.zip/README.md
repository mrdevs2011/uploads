# Hey Claude — Whisper Voice (EN/UZ, bepul, top sifat)

O'rnatish:
1. `chrome://extensions` ochib, "Developer mode"ni yoq.
2. "Load unpacked" bos, shu papkani tanla.
3. claude.ai'ni och — pastki o'ng burchakda badge chiqadi. Yoniga kelib
   🔑 belgisini bos (yoki badge'ning o'ziga bossang, key yo'q bo'lsa
   avtomatik shu panel ochiladi) — Groq API key'ni kirit (console.groq.com/keys
   dan bepul olasan, karta shart emas) va "Saqlash" bos.
4. Mikrofon ruxsatini ber.
5. "Hey Claude" de, keyin so'rovingni ayt (inglizcha yoki o'zbekcha) — jim
   qolganingda (~1.2s) avtomatik matn yoziladi va yuboriladi.

## Qanday ishlaydi
- Wake-word ("Hey Claude") — brauzerning ichki tez tanish tizimi orqali
  (internet talab qiladi).
- Wake-word eshitilgach — mikrofon yozadi, jim bo'lguningcha (yoki 20s dan
  keyin) to'xtaydi.
- Yozilgan ovoz **Groq API**ga yuboriladi, model — **whisper-large-v3**
  (Whisper'ning eng aniq versiyasi). Groq buni bepul (generous free tier)
  taqdim qiladi. Til avtomatik aniqlanadi (inglizcha/o'zbekcha).
- Natija claude.ai'ning yozish maydoniga qo'yiladi va yuborish tugmasi
  avtomatik bosiladi.

## Narx
Bepul — Groq'ning free tier limiti bor (kuniga bir necha yuzlab so'rov),
oddiy shaxsiy foydalanish uchun yetarli. Karta bog'lash shart emas.

## Sozlash
- `content.js` ichidagi `SILENCE_MS`, `SILENCE_RMS`, `MAX_RECORD_MS` —
  mikrofoningga qarab moslashtirish uchun.
- claude.ai DOM'i o'zgarsa, `findInput()` / `findSendButton()` selectorlarini
  yangilash kerak bo'lishi mumkin.

## Cheklovlar
- Faqat claude.ai domenida ishlaydi.
- API key `chrome.storage.local`da saqlanadi.
