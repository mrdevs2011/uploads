// Hey Claude — content script (runs on claude.ai)
// States: idle -> wake-listening -> recording -> transcribing -> inserting -> wake-listening

(() => {
  const WAKE_RE = /\bhe[iy]\s*(claude|klod|klaud|clod|klawd|clau?de)\b/i;
  const SILENCE_MS = 1200;      // stop recording after this much silence
  const MAX_RECORD_MS = 20000;  // hard safety cap
  const SILENCE_RMS = 0.015;    // tweak if your mic is noisy/quiet

  let enabled = false;
  let state = "idle";
  let recognition = null;
  let badge, statusText;

  chrome.storage.local.get(["heyClaudeEnabled"], (r) => {
    enabled = !!r.heyClaudeEnabled;
    injectBadge();
    if (enabled) startWakeLoop();
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "TOGGLE") {
      enabled = msg.enabled;
      if (enabled) startWakeLoop();
      else stopEverything();
    }
  });

  function injectBadge() {
    badge = document.createElement("div");
    badge.id = "hey-claude-badge";
    statusText = document.createElement("span");
    statusText.textContent = enabled ? "listening for 'Hey Claude'" : "off";
    badge.appendChild(statusText);

    const keyBtn = document.createElement("span");
    keyBtn.id = "hey-claude-keybtn";
    keyBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="14" r="4"></circle><path d="M10.5 11.5 20 2"></path><path d="M17 5l2 2"></path><path d="M14 8l2 2"></path></svg>`;
    keyBtn.title = "Groq API key";
    keyBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      openKeyPanel();
    });
    badge.appendChild(keyBtn);

    badge.addEventListener("click", async () => {
      const { groqApiKey } = await chrome.storage.local.get(["groqApiKey"]);
      if (!enabled && !groqApiKey) {
        openKeyPanel();
        return;
      }
      enabled = !enabled;
      chrome.storage.local.set({ heyClaudeEnabled: enabled });
      if (enabled) startWakeLoop();
      else stopEverything();
    });
    document.body.appendChild(badge);
    setState(enabled ? "wake-listening" : "idle");
  }

  function openKeyPanel() {
    if (document.getElementById("hey-claude-keypanel")) return;
    const panel = document.createElement("div");
    panel.id = "hey-claude-keypanel";
    panel.innerHTML = `
      <div>Groq API key <a href="https://console.groq.com/keys" target="_blank" rel="noopener">(bepul olish)</a></div>
      <input type="password" id="hey-claude-keyinput" placeholder="gsk_..." />
      <div class="hc-row">
        <button id="hey-claude-keysave">Saqlash</button>
        <button id="hey-claude-keycancel">Bekor</button>
      </div>
    `;
    document.body.appendChild(panel);

    chrome.storage.local.get(["groqApiKey"], (r) => {
      document.getElementById("hey-claude-keyinput").value = r.groqApiKey || "";
    });

    document.getElementById("hey-claude-keysave").addEventListener("click", () => {
      const val = document.getElementById("hey-claude-keyinput").value.trim();
      chrome.storage.local.set({ groqApiKey: val }, () => {
        panel.remove();
        if (val && !enabled) {
          enabled = true;
          chrome.storage.local.set({ heyClaudeEnabled: true });
          startWakeLoop();
        }
      });
    });
    document.getElementById("hey-claude-keycancel").addEventListener("click", () => panel.remove());
    document.getElementById("hey-claude-keyinput").addEventListener("keydown", (e) => {
      if (e.key === "Enter") document.getElementById("hey-claude-keysave").click();
    });
  }

  function setState(s) {
    state = s;
    if (!badge) return;
    badge.dataset.state = s;
    const labels = {
      idle: "off — click to enable",
      "wake-listening": "listening for 'Hey Claude'",
      recording: "listening to you…",
      transcribing: "transcribing…",
      inserting: "sending…",
    };
    statusText.textContent = labels[s] || s;
  }

  // ---------- Wake-word loop (native browser recognizer, cheap & fast) ----------
  function startWakeLoop() {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      statusText.textContent = "browser has no speech recognition";
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SR();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US"; // wake phrase itself is English; the command after it can be EN or UZ

    recognition.onresult = (e) => {
      let text = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        text += e.results[i][0].transcript + " ";
      }
      if (WAKE_RE.test(text)) {
        try { recognition.stop(); } catch (_) {}
        beginRecording();
      }
    };
    recognition.onerror = (e) => {
      // mic permission denied, no-speech timeouts etc. — just retry
      if (state === "wake-listening") restartWakeSoon();
    };
    recognition.onend = () => {
      if (enabled && state === "wake-listening") restartWakeSoon();
    };

    setState("wake-listening");
    try { recognition.start(); } catch (_) {}
  }

  function restartWakeSoon() {
    setTimeout(() => {
      if (enabled && state === "wake-listening") {
        try { recognition.start(); } catch (_) {}
      }
    }, 300);
  }

  function stopEverything() {
    setState("idle");
    if (recognition) { try { recognition.stop(); } catch (_) {} }
  }

  // ---------- Record the actual command after the wake word ----------
  async function beginRecording() {
    setState("recording");
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      setState("wake-listening");
      startWakeLoop();
      return;
    }

    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioCtx.createMediaStreamSource(stream);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;
    source.connect(analyser);
    const data = new Float32Array(analyser.fftSize);

    const recorder = new MediaRecorder(stream);
    const chunks = [];
    recorder.ondataavailable = (e) => chunks.push(e.data);

    let silenceStart = null;
    const hardStop = setTimeout(() => finish(), MAX_RECORD_MS);

    function rms() {
      analyser.getFloatTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i] * data[i];
      return Math.sqrt(sum / data.length);
    }

    const silenceCheck = setInterval(() => {
      const level = rms();
      if (level < SILENCE_RMS) {
        if (silenceStart === null) silenceStart = Date.now();
        else if (Date.now() - silenceStart > SILENCE_MS) finish();
      } else {
        silenceStart = null;
      }
    }, 100);

    let finished = false;
    function finish() {
      if (finished) return;
      finished = true;
      clearInterval(silenceCheck);
      clearTimeout(hardStop);
      recorder.stop();
    }

    recorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      audioCtx.close();
      const blob = new Blob(chunks, { type: "audio/webm" });
      await transcribeAndSend(blob);
    };

    recorder.start();
  }

  // ---------- Send the recorded audio to Groq's free Whisper API (fully online, no cost) ----------
  async function transcribeAndSend(blob) {
    setState("transcribing");
    const { groqApiKey } = await chrome.storage.local.get(["groqApiKey"]);
    if (!groqApiKey) {
      statusText.textContent = "API key kerak";
      openKeyPanel();
      setState("wake-listening");
      startWakeLoop();
      return;
    }

    const form = new FormData();
    form.append("file", blob, "command.webm");
    form.append("model", "whisper-large-v3");
    // language left unset on purpose: Whisper auto-detects EN/UZ etc.

    try {
      const res = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${groqApiKey}` },
        body: form,
      });
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`${res.status}: ${errText}`);
      }
      const data = await res.json();
      insertAndSend((data.text || "").trim());
    } catch (err) {
      statusText.textContent = "Whisper API xato — konsolni tekshir";
      console.error("[Hey Claude] transcription error:", err);
      setState("wake-listening");
      startWakeLoop();
    }
  }

  // ---------- Insert into claude.ai's prompt box and hit send ----------
  function findInput() {
    return (
      document.querySelector('div.ProseMirror[contenteditable="true"]') ||
      document.querySelector('div[contenteditable="true"]')
    );
  }

  function findSendButton() {
    return (
      document.querySelector('button[aria-label="Send message"]') ||
      document.querySelector('button[aria-label="Send Message"]') ||
      Array.from(document.querySelectorAll("button")).find((b) =>
        (b.getAttribute("aria-label") || "").toLowerCase().includes("send")
      )
    );
  }

  async function insertAndSend(text) {
    setState("inserting");
    if (!text) {
      setState("wake-listening");
      startWakeLoop();
      return;
    }
    const input = findInput();
    if (input) {
      input.focus();
      document.execCommand("insertText", false, text);
      input.dispatchEvent(new InputEvent("input", { bubbles: true }));
    }
    await new Promise((r) => setTimeout(r, 250));
    const btn = findSendButton();
    if (btn && !btn.disabled) {
      btn.click();
    } else if (input) {
      // fallback: simulate Enter
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    }
    setState("wake-listening");
    startWakeLoop();
  }
})();
